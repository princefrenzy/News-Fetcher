

public class NewsAutomated {
    public static void main(String args[]){

        Thread aljazeera=new Thread(new AljazeeraAutomator());
        Thread reporter=new Thread(new ReporterAutomator());
        aljazeera.start();
        reporter.start();
    }


}
